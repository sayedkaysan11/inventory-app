<?php
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_role('admin');
$pdo = db();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'add' || $action === 'edit') {
            $name = post_str('name', 100);
            if ($name === '') throw new RuntimeException('Nama kategori wajib diisi.');
            if ($action === 'add') {
                $pdo->prepare('INSERT INTO categories (name) VALUES (:n)')->execute(['n' => $name]);
                flash('Kategori ditambahkan.');
            } else {
                $pdo->prepare('UPDATE categories SET name = :n WHERE id = :id')->execute(['n' => $name, 'id' => post_int('id')]);
                flash('Kategori diperbarui.');
            }
        } elseif ($action === 'delete') {
            // FK ON DELETE RESTRICT akan menolak jika masih dipakai produk
            $pdo->prepare('DELETE FROM categories WHERE id = :id')->execute(['id' => post_int('id')]);
            flash('Kategori dihapus.');
        }
        header('Location: index.php'); exit;
    } catch (PDOException $ex) {
        $errors[] = $ex->getCode() === '23000'
            ? 'Gagal: nama kategori sudah ada, atau kategori masih dipakai produk (foreign key RESTRICT).'
            : 'Terjadi kesalahan database.';
    } catch (RuntimeException $ex) {
        $errors[] = $ex->getMessage();
    }
}
$cats = $pdo->query('SELECT c.id, c.name, COUNT(p.id) AS n FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id, c.name ORDER BY c.name')->fetchAll();
$title = 'Kategori';
require __DIR__ . '/../../views/header.php';
?>
<h1>Kategori</h1>
<?php require __DIR__ . '/../../views/errors.php'; ?>
<form method="post" class="filters">
  <?= csrf_field() ?><input type="hidden" name="action" value="add">
  <input type="text" name="name" placeholder="Nama kategori baru" required maxlength="100">
  <button>Tambah</button>
</form>
<table><tr><th>Nama</th><th>Jumlah produk</th><th>Aksi</th></tr>
<?php foreach ($cats as $c): ?>
<tr>
  <td>
    <form method="post" class="inline filters" style="margin:0">
      <?= csrf_field() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?= e($c['id']) ?>">
      <input type="text" name="name" value="<?= e($c['name']) ?>" maxlength="100"><button class="gray">Simpan</button>
    </form>
  </td>
  <td><?= e($c['n']) ?></td>
  <td>
    <form method="post" class="inline" onsubmit="return confirm('Hapus kategori ini?')">
      <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($c['id']) ?>">
      <button class="red">Hapus</button>
    </form>
  </td>
</tr>
<?php endforeach; ?>
</table>
<?php require __DIR__ . '/../../views/footer.php'; ?>
