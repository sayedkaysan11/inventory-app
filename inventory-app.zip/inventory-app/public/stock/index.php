<?php
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_login();   // admin dan staff boleh mencatat transaksi
$pdo = db();
$errors = [];

/**
 * Catat barang masuk/keluar dalam SATU database transaction:
 * lock baris produk -> validasi -> update stok -> insert histori.
 */
function record_movement(PDO $pdo, int $productId, string $type, int $qty, string $note, int $userId): void
{
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT stock FROM products WHERE id = :id FOR UPDATE');
        $st->execute(['id' => $productId]);
        $stock = $st->fetchColumn();
        if ($stock === false) throw new DomainException('Produk tidak ditemukan.');

        if ($type === 'OUT' && $qty > (int) $stock) {
            throw new DomainException("Stok tidak cukup. Stok tersedia: $stock, diminta: $qty.");
        }
        $sql = $type === 'IN'
            ? 'UPDATE products SET stock = stock + :q WHERE id = :id'
            : 'UPDATE products SET stock = stock - :q WHERE id = :id';
        $pdo->prepare($sql)->execute(['q' => $qty, 'id' => $productId]);

        $pdo->prepare('INSERT INTO stock_movements (product_id, user_id, type, quantity, note) VALUES (:p,:u,:t,:q,:n)')
            ->execute(['p' => $productId, 'u' => $userId, 't' => $type, 'q' => $qty, 'n' => $note ?: null]);
        $pdo->commit();
    } catch (Throwable $ex) {
        $pdo->rollBack();
        throw $ex;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $productId = post_int('product_id');
    $type = $_POST['type'] ?? '';
    $qty = post_int('quantity');
    $note = post_str('note', 255);

    if (!$productId) $errors[] = 'Pilih produk.';
    if (!in_array($type, ['IN', 'OUT'], true)) $errors[] = 'Tipe transaksi tidak valid.';
    if ($qty === null || $qty <= 0) $errors[] = 'Jumlah harus lebih dari nol.';

    if (!$errors) {
        try {
            record_movement($pdo, $productId, $type, $qty, $note, current_user()['id']);
            flash($type === 'IN' ? 'Barang masuk tercatat.' : 'Barang keluar tercatat.');
            header('Location: index.php'); exit;
        } catch (DomainException $ex) {
            $errors[] = $ex->getMessage();
        } catch (Throwable $ex) {
            $errors[] = 'Transaksi gagal dan dibatalkan (rollback).';
        }
    }
}

$products = $pdo->query('SELECT id, sku, name, stock FROM products ORDER BY name')->fetchAll();
$history = $pdo->query('SELECT sm.*, p.sku, p.name AS product_name, u.username FROM stock_movements sm
                        JOIN products p ON p.id = sm.product_id JOIN users u ON u.id = sm.user_id
                        ORDER BY sm.id DESC LIMIT 20')->fetchAll();
$title = 'Stok';
require __DIR__ . '/../../views/header.php';
?>
<h1>Barang Masuk / Keluar</h1>
<?php require __DIR__ . '/../../views/errors.php'; ?>
<form method="post" class="card">
  <?= csrf_field() ?>
  <label>Produk</label>
  <select name="product_id" required>
    <option value="">-- pilih --</option>
    <?php foreach ($products as $p): ?>
      <option value="<?= e($p['id']) ?>"><?= e($p['sku']) ?> - <?= e($p['name']) ?> (stok: <?= e($p['stock']) ?>)</option>
    <?php endforeach; ?>
  </select>
  <label>Tipe</label>
  <select name="type"><option value="IN">Barang masuk (IN)</option><option value="OUT">Barang keluar (OUT)</option></select>
  <label>Jumlah</label><input type="number" name="quantity" min="1" required>
  <label>Catatan</label><input type="text" name="note" maxlength="255">
  <p><button>Simpan transaksi</button></p>
</form>

<h2>20 transaksi terakhir</h2>
<table><tr><th>Waktu</th><th>Produk</th><th>Tipe</th><th>Jumlah</th><th>Oleh</th><th>Catatan</th></tr>
<?php foreach ($history as $h): ?>
<tr><td><?= e($h['created_at']) ?></td><td><?= e($h['sku']) ?> - <?= e($h['product_name']) ?></td>
<td class="<?= e($h['type']) ?>"><?= e($h['type']) ?></td><td><?= e($h['quantity']) ?></td><td><?= e($h['username']) ?></td><td><?= e($h['note']) ?></td></tr>
<?php endforeach; ?>
</table>
<?php require __DIR__ . '/../../views/footer.php'; ?>
