<?php
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_role('admin');
$pdo = db();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: null;
$errors = [];

$product = ['category_id' => '', 'sku' => '', 'name' => '', 'price' => '', 'minimum_stock' => 5, 'stock' => 0];
$selSuppliers = [];
if ($id) {
    $st = $pdo->prepare('SELECT * FROM products WHERE id = :id');
    $st->execute(['id' => $id]);
    $product = $st->fetch();
    if (!$product) { http_response_code(404); exit('Produk tidak ditemukan.'); }
    $st = $pdo->prepare('SELECT supplier_id, supplier_price FROM product_suppliers WHERE product_id = :id');
    $st->execute(['id' => $id]);
    foreach ($st->fetchAll() as $r) $selSuppliers[(int) $r['supplier_id']] = $r['supplier_price'];
}
$suppliers = $pdo->query('SELECT id, name FROM suppliers ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    [$d, $errors] = validate_product($pdo, $id);
    $product = array_merge($product, $d);
    // supplier terpilih: id harus integer
    $selSuppliers = [];
    foreach ((array) ($_POST['suppliers'] ?? []) as $sid) {
        $sid = filter_var($sid, FILTER_VALIDATE_INT);
        if ($sid) {
            $pr = filter_var($_POST['supplier_price'][$sid] ?? '', FILTER_VALIDATE_FLOAT);
            if ($pr !== false && $pr < 0) $errors[] = 'Harga supplier tidak boleh negatif.';
            $selSuppliers[$sid] = $pr === false ? null : $pr;
        }
    }
    if (!$errors) {
        $pdo->beginTransaction();
        try {
            if ($id) {
                $pdo->prepare('UPDATE products SET category_id=:category_id, sku=:sku, name=:name, price=:price, minimum_stock=:minimum_stock WHERE id=:id')
                    ->execute($d + ['id' => $id]);
            } else {
                $pdo->prepare('INSERT INTO products (category_id, sku, name, price, minimum_stock) VALUES (:category_id,:sku,:name,:price,:minimum_stock)')
                    ->execute($d);
                $id = (int) $pdo->lastInsertId();
            }
            // Sinkronisasi many-to-many
            $pdo->prepare('DELETE FROM product_suppliers WHERE product_id = :id')->execute(['id' => $id]);
            $ins = $pdo->prepare('INSERT INTO product_suppliers (product_id, supplier_id, supplier_price) VALUES (:p,:s,:pr)');
            foreach ($selSuppliers as $sid => $pr) $ins->execute(['p' => $id, 's' => $sid, 'pr' => $pr]);
            $pdo->commit();
            flash('Produk disimpan. Stok diubah lewat menu Stok (barang masuk/keluar).');
            header('Location: index.php'); exit;
        } catch (Throwable $ex) {
            $pdo->rollBack();
            $errors[] = 'Gagal menyimpan produk.';
        }
    }
}
$cats = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$title = $id ? 'Edit Produk' : 'Produk Baru';
require __DIR__ . '/../../views/header.php';
?>
<h1><?= e($title) ?></h1>
<?php require __DIR__ . '/../../views/errors.php'; ?>
<form method="post" class="card">
  <?= csrf_field() ?>
  <label>Kategori</label>
  <select name="category_id" required>
    <option value="">-- pilih --</option>
    <?php foreach ($cats as $c): ?>
      <option value="<?= e($c['id']) ?>" <?= (int) $product['category_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <label>SKU (unik)</label><input type="text" name="sku" value="<?= e($product['sku']) ?>" maxlength="50" required>
  <label>Nama</label><input type="text" name="name" value="<?= e($product['name']) ?>" maxlength="150" required>
  <label>Harga</label><input type="number" name="price" value="<?= e($product['price']) ?>" step="0.01" required>
  <label>Stok minimum</label><input type="number" name="minimum_stock" value="<?= e($product['minimum_stock']) ?>" required>
  <label>Supplier (many-to-many)</label>
  <?php foreach ($suppliers as $s): $on = array_key_exists((int) $s['id'], $selSuppliers); ?>
    <div><label style="font-weight:400;display:inline">
      <input type="checkbox" name="suppliers[]" value="<?= e($s['id']) ?>" <?= $on ? 'checked' : '' ?>> <?= e($s['name']) ?></label>
      &nbsp;harga: <input type="number" step="0.01" style="width:150px" name="supplier_price[<?= e($s['id']) ?>]" value="<?= e($selSuppliers[(int) $s['id']] ?? '') ?>">
    </div>
  <?php endforeach; ?>
  <p><button>Simpan</button> <a class="btn gray" href="index.php">Batal</a></p>
</form>
<?php require __DIR__ . '/../../views/footer.php'; ?>
