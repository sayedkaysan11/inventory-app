<?php
require_once __DIR__ . '/../../helpers/auth.php';
require_login();
$pdo = db();
$isAdmin = current_user()['role'] === 'admin';

// ---- Hapus produk (admin) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_role('admin');
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $st = $pdo->prepare('SELECT COUNT(*) FROM stock_movements WHERE product_id = :id');
    $st->execute(['id' => $id]);
    if ($st->fetchColumn() > 0) {
        flash('Produk punya histori transaksi dan tidak boleh dihapus.', 'error');
    } else {
        $pdo->prepare('DELETE FROM products WHERE id = :id')->execute(['id' => $id]);
        flash('Produk dihapus.');
    }
    header('Location: index.php'); exit;
}

// ---- Search, filter, sorting (allowlist), pagination ----
$q    = trim((string) ($_GET['q'] ?? ''));
$cat  = filter_input(INPUT_GET, 'category_id', FILTER_VALIDATE_INT) ?: 0;
$sortAllowed = ['name' => 'p.name', 'price' => 'p.price', 'stock' => 'p.stock'];
$sort = array_key_exists($_GET['sort'] ?? '', $sortAllowed) ? $_GET['sort'] : 'name';
$dir  = strtoupper($_GET['dir'] ?? 'ASC') === 'DESC' ? 'DESC' : 'ASC';
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 5;

$where = []; $params = [];
if ($q !== '') {
    $where[] = '(p.name LIKE :q1 OR p.sku LIKE :q2)';
    $params['q1'] = $params['q2'] = '%' . $q . '%';
}
if ($cat) { $where[] = 'p.category_id = :cat'; $params['cat'] = $cat; }
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$st = $pdo->prepare("SELECT COUNT(*) FROM products p $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$totalPages = max(1, (int) ceil($total / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

// Nama kolom dari allowlist (aman), nilai di-bind
$sql = "SELECT p.*, c.name AS category_name FROM products p
        JOIN categories c ON c.id = p.category_id $whereSql
        ORDER BY {$sortAllowed[$sort]} $dir LIMIT :limit OFFSET :offset";
$st = $pdo->prepare($sql);
foreach ($params as $k => $v) $st->bindValue(':' . $k, $v);
$st->bindValue(':limit', $perPage, PDO::PARAM_INT);
$st->bindValue(':offset', $offset, PDO::PARAM_INT);
$st->execute();
$products = $st->fetchAll();
$cats = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();

// Link yang mempertahankan search/filter/sort
function qs(array $over = []): string {
    global $q, $cat, $sort, $dir, $page;
    return '?' . http_build_query(array_merge(['q' => $q, 'category_id' => $cat ?: '', 'sort' => $sort, 'dir' => $dir, 'page' => $page], $over));
}
function sortLink(string $col, string $label): string {
    global $sort, $dir;
    $nd = ($sort === $col && $dir === 'ASC') ? 'DESC' : 'ASC';
    $arrow = $sort === $col ? ($dir === 'ASC' ? ' ▲' : ' ▼') : '';
    return '<a href="' . e(qs(['sort' => $col, 'dir' => $nd, 'page' => 1])) . '">' . e($label) . $arrow . '</a>';
}

$title = 'Produk';
require __DIR__ . '/../../views/header.php';
?>
<h1>Produk</h1>
<form method="get" class="filters">
  <input type="text" name="q" value="<?= e($q) ?>" placeholder="Cari nama / SKU">
  <select name="category_id">
    <option value="">Semua kategori</option>
    <?php foreach ($cats as $c): ?>
      <option value="<?= e($c['id']) ?>" <?= $cat === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <input type="hidden" name="sort" value="<?= e($sort) ?>"><input type="hidden" name="dir" value="<?= e($dir) ?>">
  <button>Cari</button> <a class="btn gray" href="index.php">Reset</a>
  <?php if ($isAdmin): ?><a class="btn" href="form.php">+ Produk baru</a><?php endif; ?>
</form>
<table>
<tr><th>SKU</th><th><?= sortLink('name', 'Nama') ?></th><th>Kategori</th><th><?= sortLink('price', 'Harga') ?></th><th><?= sortLink('stock', 'Stok') ?></th><?php if ($isAdmin): ?><th>Aksi</th><?php endif; ?></tr>
<?php foreach ($products as $p): $isLow = $p['stock'] <= $p['minimum_stock']; ?>
<tr class="<?= $isLow ? 'low' : '' ?>">
  <td><?= e($p['sku']) ?></td><td><?= e($p['name']) ?></td><td><?= e($p['category_name']) ?></td>
  <td><?= e(rupiah($p['price'])) ?></td>
  <td><?= e($p['stock']) ?> <?= $isLow ? '<span class="badge">rendah</span>' : '' ?></td>
  <?php if ($isAdmin): ?>
  <td>
    <a class="btn gray" href="form.php?id=<?= e($p['id']) ?>">Edit</a>
    <form method="post" class="inline" onsubmit="return confirm('Hapus produk?')">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= e($p['id']) ?>"><button class="red">Hapus</button>
    </form>
  </td>
  <?php endif; ?>
</tr>
<?php endforeach; if (!$products): ?><tr><td colspan="6">Tidak ada produk.</td></tr><?php endif; ?>
</table>
<p class="muted"><?= e($total) ?> produk &middot; halaman <?= e($page) ?> dari <?= e($totalPages) ?></p>
<div class="pagination">
<?php for ($i = 1; $i <= $totalPages; $i++): ?>
  <?= $i === $page ? '<span class="cur">' . $i . '</span>' : '<a href="' . e(qs(['page' => $i])) . '">' . $i . '</a>' ?>
<?php endfor; ?>
</div>
<?php require __DIR__ . '/../../views/footer.php'; ?>
