<?php
require_once __DIR__ . '/../../helpers/auth.php';
require_role('admin');   // staff -> 403 Forbidden
$users = db()->query('SELECT u.id, u.username, u.role, up.full_name FROM users u LEFT JOIN user_profiles up ON up.user_id = u.id ORDER BY u.id')->fetchAll();
$title = 'User';
require __DIR__ . '/../../views/header.php';
?>
<h1>Manajemen User</h1>
<table><tr><th>ID</th><th>Username</th><th>Nama lengkap</th><th>Role</th></tr>
<?php foreach ($users as $u): ?>
<tr><td><?= e($u['id']) ?></td><td><?= e($u['username']) ?></td><td><?= e($u['full_name']) ?></td><td><?= e($u['role']) ?></td></tr>
<?php endforeach; ?>
</table>
<?php require __DIR__ . '/../../views/footer.php'; ?>
