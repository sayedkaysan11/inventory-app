<?php
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_role('admin');
$pdo = db();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $name = post_str('name', 100);
    $phone = post_str('phone', 30);
    try {
        if ($action === 'add') {
            if ($name === '') throw new RuntimeException('Nama supplier wajib diisi.');
            $pdo->prepare('INSERT INTO suppliers (name, phone) VALUES (:n,:p)')->execute(['n' => $name, 'p' => $phone ?: null]);
            flash('Supplier ditambahkan.');
        } elseif ($action === 'delete') {
            $pdo->prepare('DELETE FROM suppliers WHERE id = :id')->execute(['id' => post_int('id')]);
            flash('Supplier dihapus.');
        }
        header('Location: index.php'); exit;
    } catch (RuntimeException $ex) { $errors[] = $ex->getMessage(); }
}
$rows = $pdo->query('SELECT s.id, s.name, s.phone, COUNT(ps.product_id) AS n FROM suppliers s LEFT JOIN product_suppliers ps ON ps.supplier_id=s.id GROUP BY s.id, s.name, s.phone ORDER BY s.name')->fetchAll();
$title = 'Supplier';
require __DIR__ . '/../../views/header.php';
?>
<h1>Supplier</h1>
<?php require __DIR__ . '/../../views/errors.php'; ?>
<form method="post" class="filters">
  <?= csrf_field() ?><input type="hidden" name="action" value="add">
  <input type="text" name="name" placeholder="Nama supplier" required maxlength="100">
  <input type="text" name="phone" placeholder="Telepon" maxlength="30">
  <button>Tambah</button>
</form>
<table><tr><th>Nama</th><th>Telepon</th><th>Jumlah produk</th><th>Aksi</th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= e($r['name']) ?></td><td><?= e($r['phone']) ?></td><td><?= e($r['n']) ?></td>
<td><form method="post" class="inline" onsubmit="return confirm('Hapus supplier?')"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($r['id']) ?>"><button class="red">Hapus</button></form></td></tr>
<?php endforeach; ?>
</table>
<?php require __DIR__ . '/../../views/footer.php'; ?>
